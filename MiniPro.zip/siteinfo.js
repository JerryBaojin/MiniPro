var siteInfo = {
  'title': '',
  'uniacid': '97',
  'acid': '97',
  'multiid': '0',
  'version': '1.0',
  'siteroot': 'https://wzqd.qidongwx.com/app/index.php',
  'design_method': '3',
  'redirect_module': '',
  'template': ''
}
module.exports = siteInfo